import 'package:flutter/material.dart';
import '../presentation/splash_screen/splash_screen.dart';
import '../presentation/now_playing/now_playing.dart';
import '../presentation/music_library/music_library.dart';
import '../presentation/settings/settings.dart';
import '../presentation/playlists/playlists.dart';
import '../presentation/playlist_detail/playlist_detail.dart';

class AppRoutes {
  static const String initial = '/';
  static const String splashScreen = '/splash-screen';
  static const String musicLibrary = '/music-library';
  static const String nowPlaying = '/now-playing';
  static const String playlists = '/playlists';
  static const String playlistDetail = '/playlist-detail';
  static const String settings = '/settings';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const SplashScreen(),
    splashScreen: (context) => const SplashScreen(),
    musicLibrary: (context) => const MusicLibrary(),
    nowPlaying: (context) => const NowPlaying(),
    playlists: (context) => const Playlists(),
    playlistDetail: (context) => const PlaylistDetail(),
    settings: (context) => const Settings(),
  };
}

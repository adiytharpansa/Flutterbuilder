import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _logoAnimationController;
  late AnimationController _progressAnimationController;
  late Animation<double> _logoScaleAnimation;
  late Animation<double> _logoFadeAnimation;
  late Animation<double> _progressAnimation;

  String _loadingText = 'Memulai Musikku...';
  bool _showProgress = false;
  bool _hasPermissions = false;
  bool _hasMusicFiles = false;

  // Mock data for music scanning simulation
  final List<String> _loadingSteps = [
    'Memulai Musikku...',
    'Meminta izin akses penyimpanan...',
    'Memindai perpustakaan musik...',
    'Memuat preferensi pengguna...',
    'Menyiapkan pemutar audio...',
    'Selesai!'
  ];

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _startSplashSequence();
  }

  void _initializeAnimations() {
    _logoAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _progressAnimationController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );

    _logoScaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _logoAnimationController,
      curve: Curves.elasticOut,
    ));

    _logoFadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _logoAnimationController,
      curve: Curves.easeInOut,
    ));

    _progressAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _progressAnimationController,
      curve: Curves.easeInOut,
    ));
  }

  Future<void> _startSplashSequence() async {
    // Hide system UI for immersive experience
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    // Start logo animation
    _logoAnimationController.forward();

    // Wait for logo animation to complete
    await Future.delayed(const Duration(milliseconds: 800));

    // Show progress indicator
    setState(() {
      _showProgress = true;
    });

    // Start progress animation
    _progressAnimationController.forward();

    // Simulate initialization steps
    await _simulateInitialization();

    // Navigate to appropriate screen
    await _navigateToNextScreen();
  }

  Future<void> _simulateInitialization() async {
    for (int i = 0; i < _loadingSteps.length; i++) {
      setState(() {
        _loadingText = _loadingSteps[i];
      });

      // Simulate different loading times for each step
      int delay = i == 2 ? 1500 : 600; // Longer delay for music scanning
      await Future.delayed(Duration(milliseconds: delay));

      // Simulate permission and file checks
      if (i == 1) {
        _hasPermissions = true;
      } else if (i == 2) {
        _hasMusicFiles = true;
      }
    }
  }

  Future<void> _navigateToNextScreen() async {
    // Restore system UI
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

    await Future.delayed(const Duration(milliseconds: 500));

    if (!mounted) return;

    // Navigation logic based on app state
    if (!_hasPermissions) {
      _showPermissionDialog();
    } else if (!_hasMusicFiles) {
      _showNoMusicDialog();
    } else {
      // Navigate to music library
      Navigator.pushReplacementNamed(context, '/music-library');
    }
  }

  void _showPermissionDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text(
          'Izin Diperlukan',
          style: AppTheme.lightTheme.textTheme.titleLarge,
        ),
        content: Text(
          'Musikku memerlukan akses ke penyimpanan untuk memindai file musik Anda. Silakan berikan izin di pengaturan aplikasi.',
          style: AppTheme.lightTheme.textTheme.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.pushReplacementNamed(context, '/settings');
            },
            child: const Text('Pengaturan'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              _startSplashSequence();
            },
            child: const Text('Coba Lagi'),
          ),
        ],
      ),
    );
  }

  void _showNoMusicDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text(
          'Tidak Ada Musik',
          style: AppTheme.lightTheme.textTheme.titleLarge,
        ),
        content: Text(
          'Tidak ditemukan file musik di perangkat Anda. Silakan tambahkan file musik ke penyimpanan perangkat terlebih dahulu.',
          style: AppTheme.lightTheme.textTheme.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _startSplashSequence();
            },
            child: const Text('Pindai Ulang'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.pushReplacementNamed(context, '/music-library');
            },
            child: const Text('Lanjutkan'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _logoAnimationController.dispose();
    _progressAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: 100.w,
        height: 100.h,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppTheme.lightTheme.colorScheme.secondary,
              AppTheme.lightTheme.colorScheme.secondary.withValues(alpha: 0.8),
              AppTheme.lightTheme.colorScheme.primary,
            ],
            stops: const [0.0, 0.6, 1.0],
          ),
        ),
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Logo Section
              Expanded(
                flex: 3,
                child: Center(
                  child: AnimatedBuilder(
                    animation: _logoAnimationController,
                    builder: (context, child) {
                      return Transform.scale(
                        scale: _logoScaleAnimation.value,
                        child: Opacity(
                          opacity: _logoFadeAnimation.value,
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              // App Logo
                              Container(
                                width: 25.w,
                                height: 25.w,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(4.w),
                                  boxShadow: [
                                    BoxShadow(
                                      color:
                                          Colors.black.withValues(alpha: 0.2),
                                      blurRadius: 20,
                                      offset: const Offset(0, 10),
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: CustomIconWidget(
                                    iconName: 'music_note',
                                    color: AppTheme
                                        .lightTheme.colorScheme.secondary,
                                    size: 12.w,
                                  ),
                                ),
                              ),
                              SizedBox(height: 3.h),
                              // App Name
                              Text(
                                'Musikku',
                                style: AppTheme
                                    .lightTheme.textTheme.headlineLarge
                                    ?.copyWith(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.2,
                                ),
                              ),
                              SizedBox(height: 1.h),
                              Text(
                                'Pemutar Musik Offline',
                                style: AppTheme.lightTheme.textTheme.bodyLarge
                                    ?.copyWith(
                                  color: Colors.white.withValues(alpha: 0.8),
                                  fontWeight: FontWeight.w300,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),

              // Loading Section
              Expanded(
                flex: 1,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Progress Indicator
                    _showProgress
                        ? AnimatedBuilder(
                            animation: _progressAnimation,
                            builder: (context, child) {
                              return Column(
                                children: [
                                  Container(
                                    width: 60.w,
                                    height: 0.5.h,
                                    decoration: BoxDecoration(
                                      color:
                                          Colors.white.withValues(alpha: 0.3),
                                      borderRadius: BorderRadius.circular(1.h),
                                    ),
                                    child: FractionallySizedBox(
                                      alignment: Alignment.centerLeft,
                                      widthFactor: _progressAnimation.value,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius:
                                              BorderRadius.circular(1.h),
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 2.h),
                                  Text(
                                    _loadingText,
                                    style: AppTheme
                                        .lightTheme.textTheme.bodyMedium
                                        ?.copyWith(
                                      color:
                                          Colors.white.withValues(alpha: 0.9),
                                      fontWeight: FontWeight.w400,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ],
                              );
                            },
                          )
                        : SizedBox(
                            width: 6.w,
                            height: 6.w,
                            child: CircularProgressIndicator(
                              strokeWidth: 0.5.w,
                              valueColor: const AlwaysStoppedAnimation<Color>(
                                  Colors.white),
                            ),
                          ),
                  ],
                ),
              ),

              // Bottom Spacing
              SizedBox(height: 5.h),
            ],
          ),
        ),
      ),
    );
  }
}

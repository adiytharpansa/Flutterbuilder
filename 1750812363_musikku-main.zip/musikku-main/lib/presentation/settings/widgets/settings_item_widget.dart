import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SettingsItemWidget extends StatelessWidget {
  final String title;
  final String subtitle;
  final String type;
  final dynamic value;
  final Function(dynamic)? onChanged;
  final VoidCallback? onTap;

  const SettingsItemWidget({
    super.key,
    required this.title,
    required this.subtitle,
    required this.type,
    this.value,
    this.onChanged,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: type == 'switch' || type == 'slider' ? null : onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 3.h),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                      fontWeight: FontWeight.w500,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: 0.5.h),
                  Text(
                    subtitle,
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            SizedBox(width: 3.w),
            _buildTrailingWidget(),
          ],
        ),
      ),
    );
  }

  Widget _buildTrailingWidget() {
    switch (type) {
      case 'switch':
        return Switch(
          value: value as bool? ?? false,
          onChanged: onChanged,
          activeColor: AppTheme.lightTheme.colorScheme.secondary,
        );
      case 'slider':
        return SizedBox(
          width: 20.w,
          child: Column(
            children: [
              Text(
                '${(value as double? ?? 0.0).toStringAsFixed(1)}s',
                style: AppTheme.lightTheme.textTheme.bodySmall,
              ),
              Slider(
                value: value as double? ?? 0.0,
                min: 0.0,
                max: 10.0,
                divisions: 20,
                onChanged: onChanged,
                activeColor: AppTheme.lightTheme.colorScheme.secondary,
              ),
            ],
          ),
        );
      case 'navigation':
        return CustomIconWidget(
          iconName: 'chevron_right',
          color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
          size: 20,
        );
      case 'action':
        return CustomIconWidget(
          iconName: 'refresh',
          color: AppTheme.lightTheme.colorScheme.secondary,
          size: 20,
        );
      case 'info':
        return CustomIconWidget(
          iconName: 'info_outline',
          color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
          size: 20,
        );
      default:
        return SizedBox.shrink();
    }
  }
}

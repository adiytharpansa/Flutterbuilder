import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/settings_item_widget.dart';
import './widgets/settings_section_widget.dart';
import './widgets/storage_usage_widget.dart';

class Settings extends StatefulWidget {
  const Settings({super.key});

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> with TickerProviderStateMixin {
  late TabController _tabController;
  int _currentIndex = 3; // Settings tab active

  // Settings state variables
  bool _volumeNormalization = true;
  bool _gaplessPlayback = false;
  bool _autoPlayNext = true;
  bool _crossfadeEnabled = false;
  double _crossfadeDuration = 3.0;
  final String _selectedTheme = 'auto';
  final String _selectedLanguage = 'id';
  final String _defaultView = 'grid';
  bool _sleepTimerEnabled = false;
  int _sleepTimerMinutes = 30;

  final List<Map<String, dynamic>> _mockSettingsData = [
    {
      "section": "Audio Settings",
      "items": [
        {
          "title": "Equalizer",
          "subtitle": "Customize audio output",
          "type": "navigation"
        },
        {
          "title": "Audio Format",
          "subtitle": "High Quality (320kbps)",
          "type": "navigation"
        },
        {
          "title": "Volume Normalization",
          "subtitle": "Consistent volume levels",
          "type": "switch"
        },
        {
          "title": "Crossfade",
          "subtitle": "Smooth track transitions",
          "type": "switch"
        },
        {
          "title": "Crossfade Duration",
          "subtitle": "3 seconds",
          "type": "slider"
        },
      ]
    },
    {
      "section": "Playback",
      "items": [
        {
          "title": "Auto-play Next Song",
          "subtitle": "Continue playing after track ends",
          "type": "switch"
        },
        {
          "title": "Repeat Mode Default",
          "subtitle": "Off",
          "type": "navigation"
        },
        {
          "title": "Shuffle Behavior",
          "subtitle": "True random",
          "type": "navigation"
        },
        {
          "title": "Gapless Playback",
          "subtitle": "Seamless album experience",
          "type": "switch"
        },
      ]
    },
    {
      "section": "Library Management",
      "items": [
        {
          "title": "Rescan Music Library",
          "subtitle": "Find new music files",
          "type": "action"
        },
        {
          "title": "File Format Filters",
          "subtitle": "MP3, FLAC, AAC",
          "type": "navigation"
        },
        {
          "title": "Folder Exclusions",
          "subtitle": "2 folders excluded",
          "type": "navigation"
        },
        {
          "title": "Storage Location",
          "subtitle": "Internal Storage",
          "type": "navigation"
        },
      ]
    },
    {
      "section": "Interface",
      "items": [
        {"title": "Theme", "subtitle": "Auto (System)", "type": "navigation"},
        {
          "title": "Language",
          "subtitle": "Bahasa Indonesia",
          "type": "navigation"
        },
        {
          "title": "Default View",
          "subtitle": "Grid View",
          "type": "navigation"
        },
      ]
    },
    {
      "section": "Advanced",
      "items": [
        {
          "title": "Sleep Timer",
          "subtitle": "30 minutes default",
          "type": "navigation"
        },
        {
          "title": "Headphone Controls",
          "subtitle": "Configure button actions",
          "type": "navigation"
        },
        {
          "title": "Lock Screen Behavior",
          "subtitle": "Show full controls",
          "type": "navigation"
        },
      ]
    },
    {
      "section": "About",
      "items": [
        {"title": "App Version", "subtitle": "1.0.0 (Build 1)", "type": "info"},
        {
          "title": "Legal Information",
          "subtitle": "Licenses and terms",
          "type": "navigation"
        },
        {
          "title": "Privacy Policy",
          "subtitle": "How we handle your data",
          "type": "navigation"
        },
      ]
    }
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this, initialIndex: 3);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: _buildAppBar(),
      body: _buildBody(),
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppTheme.lightTheme.appBarTheme.backgroundColor,
      elevation: 0,
      title: Text(
        'Pengaturan',
        style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
          fontWeight: FontWeight.w600,
        ),
      ),
      actions: [
        IconButton(
          onPressed: () => _showSearchDialog(),
          icon: CustomIconWidget(
            iconName: 'search',
            color: AppTheme.lightTheme.colorScheme.onSurface,
            size: 24,
          ),
        ),
        SizedBox(width: 2.w),
      ],
    );
  }

  Widget _buildBody() {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            child: StorageUsageWidget(),
          ),
        ),
        SliverList(
          delegate: SliverChildBuilderDelegate(
            (context, index) {
              final section = _mockSettingsData[index];
              return Padding(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                child: SettingsSectionWidget(
                  title: section["section"] as String,
                  items: (section["items"] as List)
                      .map((item) => SettingsItemWidget(
                            title: item["title"] as String,
                            subtitle: item["subtitle"] as String,
                            type: item["type"] as String,
                            value: _getSettingValue(item["title"] as String),
                            onChanged: (value) => _handleSettingChange(
                                item["title"] as String, value),
                            onTap: () =>
                                _handleSettingTap(item["title"] as String),
                          ))
                      .toList(),
                ),
              );
            },
            childCount: _mockSettingsData.length,
          ),
        ),
        SliverToBoxAdapter(
          child: SizedBox(height: 10.h),
        ),
      ],
    );
  }

  Widget _buildBottomNavigationBar() {
    return BottomNavigationBar(
      currentIndex: _currentIndex,
      type: BottomNavigationBarType.fixed,
      backgroundColor:
          AppTheme.lightTheme.bottomNavigationBarTheme.backgroundColor,
      selectedItemColor:
          AppTheme.lightTheme.bottomNavigationBarTheme.selectedItemColor,
      unselectedItemColor:
          AppTheme.lightTheme.bottomNavigationBarTheme.unselectedItemColor,
      selectedLabelStyle:
          AppTheme.lightTheme.bottomNavigationBarTheme.selectedLabelStyle,
      unselectedLabelStyle:
          AppTheme.lightTheme.bottomNavigationBarTheme.unselectedLabelStyle,
      onTap: _onBottomNavTap,
      items: [
        BottomNavigationBarItem(
          icon: CustomIconWidget(
            iconName: 'library_music',
            color: _currentIndex == 0
                ? AppTheme
                    .lightTheme.bottomNavigationBarTheme.selectedItemColor!
                : AppTheme
                    .lightTheme.bottomNavigationBarTheme.unselectedItemColor!,
            size: 24,
          ),
          label: 'Perpustakaan',
        ),
        BottomNavigationBarItem(
          icon: CustomIconWidget(
            iconName: 'playlist_play',
            color: _currentIndex == 1
                ? AppTheme
                    .lightTheme.bottomNavigationBarTheme.selectedItemColor!
                : AppTheme
                    .lightTheme.bottomNavigationBarTheme.unselectedItemColor!,
            size: 24,
          ),
          label: 'Playlist',
        ),
        BottomNavigationBarItem(
          icon: CustomIconWidget(
            iconName: 'music_note',
            color: _currentIndex == 2
                ? AppTheme
                    .lightTheme.bottomNavigationBarTheme.selectedItemColor!
                : AppTheme
                    .lightTheme.bottomNavigationBarTheme.unselectedItemColor!,
            size: 24,
          ),
          label: 'Sedang Diputar',
        ),
        BottomNavigationBarItem(
          icon: CustomIconWidget(
            iconName: 'settings',
            color: _currentIndex == 3
                ? AppTheme
                    .lightTheme.bottomNavigationBarTheme.selectedItemColor!
                : AppTheme
                    .lightTheme.bottomNavigationBarTheme.unselectedItemColor!,
            size: 24,
          ),
          label: 'Pengaturan',
        ),
      ],
    );
  }

  void _onBottomNavTap(int index) {
    setState(() {
      _currentIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/music-library');
        break;
      case 1:
        Navigator.pushNamed(context, '/playlists');
        break;
      case 2:
        Navigator.pushNamed(context, '/now-playing');
        break;
      case 3:
        // Already on settings
        break;
    }
  }

  dynamic _getSettingValue(String title) {
    switch (title) {
      case 'Volume Normalization':
        return _volumeNormalization;
      case 'Gapless Playback':
        return _gaplessPlayback;
      case 'Auto-play Next Song':
        return _autoPlayNext;
      case 'Crossfade':
        return _crossfadeEnabled;
      case 'Crossfade Duration':
        return _crossfadeDuration;
      case 'Sleep Timer':
        return _sleepTimerEnabled;
      default:
        return null;
    }
  }

  void _handleSettingChange(String title, dynamic value) {
    setState(() {
      switch (title) {
        case 'Volume Normalization':
          _volumeNormalization = value as bool;
          break;
        case 'Gapless Playback':
          _gaplessPlayback = value as bool;
          break;
        case 'Auto-play Next Song':
          _autoPlayNext = value as bool;
          break;
        case 'Crossfade':
          _crossfadeEnabled = value as bool;
          break;
        case 'Crossfade Duration':
          _crossfadeDuration = value as double;
          break;
        case 'Sleep Timer':
          _sleepTimerEnabled = value as bool;
          break;
      }
    });
  }

  void _handleSettingTap(String title) {
    switch (title) {
      case 'Equalizer':
        _showEqualizerDialog();
        break;
      case 'Audio Format':
        _showAudioFormatDialog();
        break;
      case 'Theme':
        _showThemeDialog();
        break;
      case 'Language':
        _showLanguageDialog();
        break;
      case 'Rescan Music Library':
        _showRescanDialog();
        break;
      case 'Sleep Timer':
        _showSleepTimerDialog();
        break;
      default:
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$title diklik'),
            duration: Duration(seconds: 1),
          ),
        );
    }
  }

  void _showSearchDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Cari Pengaturan'),
        content: TextField(
          decoration: InputDecoration(
            hintText: 'Ketik untuk mencari...',
            prefixIcon: CustomIconWidget(
              iconName: 'search',
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 20,
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Tutup'),
          ),
        ],
      ),
    );
  }

  void _showEqualizerDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Equalizer'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Preset Equalizer'),
            SizedBox(height: 2.h),
            ...['Rock', 'Pop', 'Jazz', 'Classical', 'Custom'].map(
              (preset) => ListTile(
                title: Text(preset),
                leading: Radio<String>(
                  value: preset,
                  groupValue: 'Rock',
                  onChanged: (value) {},
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Tutup'),
          ),
        ],
      ),
    );
  }

  void _showAudioFormatDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Format Audio'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ...['High Quality (320kbps)', 'Standard (192kbps)', 'Low (128kbps)']
                .map(
              (format) => ListTile(
                title: Text(format),
                leading: Radio<String>(
                  value: format,
                  groupValue: 'High Quality (320kbps)',
                  onChanged: (value) {},
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Tutup'),
          ),
        ],
      ),
    );
  }

  void _showThemeDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Pilih Tema'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ...['Terang', 'Gelap', 'Auto (Sistem)'].map(
              (theme) => ListTile(
                title: Text(theme),
                leading: Radio<String>(
                  value: theme,
                  groupValue: 'Auto (Sistem)',
                  onChanged: (value) {},
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Tutup'),
          ),
        ],
      ),
    );
  }

  void _showLanguageDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Pilih Bahasa'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ...['Bahasa Indonesia', 'English'].map(
              (language) => ListTile(
                title: Text(language),
                leading: Radio<String>(
                  value: language,
                  groupValue: 'Bahasa Indonesia',
                  onChanged: (value) {},
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Tutup'),
          ),
        ],
      ),
    );
  }

  void _showRescanDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Pindai Ulang Perpustakaan'),
        content: Text(
            'Apakah Anda ingin memindai ulang perpustakaan musik untuk mencari file baru?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Memindai perpustakaan musik...')),
              );
            },
            child: Text('Pindai'),
          ),
        ],
      ),
    );
  }

  void _showSleepTimerDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Sleep Timer'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Durasi Default: $_sleepTimerMinutes menit'),
            SizedBox(height: 2.h),
            Slider(
              value: _sleepTimerMinutes.toDouble(),
              min: 5,
              max: 120,
              divisions: 23,
              label: '$_sleepTimerMinutes menit',
              onChanged: (value) {
                setState(() {
                  _sleepTimerMinutes = value.round();
                });
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Tutup'),
          ),
        ],
      ),
    );
  }
}

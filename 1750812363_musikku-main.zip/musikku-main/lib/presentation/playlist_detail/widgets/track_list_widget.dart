import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import './track_item_widget.dart';

class TrackListWidget extends StatelessWidget {
  final List<Map<String, dynamic>> tracks;
  final bool isEditMode;
  final List<int> selectedTracks;
  final Function(Map<String, dynamic>) onTrackTap;
  final Function(Map<String, dynamic>) onTrackLongPress;
  final Function(Map<String, dynamic>) onRemoveTrack;

  const TrackListWidget({
    super.key,
    required this.tracks,
    required this.isEditMode,
    required this.selectedTracks,
    required this.onTrackTap,
    required this.onTrackLongPress,
    required this.onRemoveTrack,
  });

  @override
  Widget build(BuildContext context) {
    if (tracks.isEmpty) {
      return Container(
        padding: EdgeInsets.all(4.w),
        child: Center(
          child: Column(
            children: [
              SizedBox(height: 8.h),
              CustomIconWidget(
                iconName: 'music_note',
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 64,
              ),
              SizedBox(height: 2.h),
              Text(
                'Tidak ada lagu ditemukan',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
              SizedBox(height: 1.h),
              Text(
                'Coba ubah kata kunci pencarian',
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Section Header
          if (!isEditMode)
            Padding(
              padding: EdgeInsets.symmetric(vertical: 2.h),
              child: Row(
                children: [
                  Text(
                    'Lagu',
                    style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Spacer(),
                  Text(
                    '${tracks.length} lagu',
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),

          // Track List
          ListView.separated(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemCount: tracks.length,
            separatorBuilder: (context, index) => SizedBox(height: 1.h),
            itemBuilder: (context, index) {
              final track = tracks[index];
              final isSelected = selectedTracks.contains(track["id"] as int);
              final isPlaying = track["isPlaying"] as bool? ?? false;

              return TrackItemWidget(
                track: track,
                index: index,
                isEditMode: isEditMode,
                isSelected: isSelected,
                isPlaying: isPlaying,
                onTap: () => onTrackTap(track),
                onLongPress: () => onTrackLongPress(track),
                onRemove: () => onRemoveTrack(track),
              );
            },
          ),

          SizedBox(height: 4.h),
        ],
      ),
    );
  }
}

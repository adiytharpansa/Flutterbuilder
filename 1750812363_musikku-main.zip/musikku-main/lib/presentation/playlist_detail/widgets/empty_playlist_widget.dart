import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class EmptyPlaylistWidget extends StatelessWidget {
  final VoidCallback onAddSongs;

  const EmptyPlaylistWidget({
    super.key,
    required this.onAddSongs,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4.w),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Empty State Illustration
          Container(
            width: 40.w,
            height: 40.w,
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.secondary
                  .withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: CustomIconWidget(
                iconName: 'queue_music',
                color: AppTheme.lightTheme.colorScheme.secondary,
                size: 64,
              ),
            ),
          ),

          SizedBox(height: 4.h),

          // Title
          Text(
            'Playlist Kosong',
            style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.w600,
            ),
            textAlign: TextAlign.center,
          ),

          SizedBox(height: 2.h),

          // Description
          Text(
            'Playlist ini belum memiliki lagu.\nTambahkan lagu dari perpustakaan musik Anda.',
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
            textAlign: TextAlign.center,
          ),

          SizedBox(height: 4.h),

          // Add Songs Button
          ElevatedButton.icon(
            onPressed: onAddSongs,
            icon: CustomIconWidget(
              iconName: 'add',
              color: AppTheme.lightTheme.colorScheme.onSecondary,
              size: 20,
            ),
            label: Text(
              'Tambah Lagu',
              style: AppTheme.lightTheme.textTheme.labelLarge?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSecondary,
              ),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
              foregroundColor: AppTheme.lightTheme.colorScheme.onSecondary,
              padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 1.5.h),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(25),
              ),
            ),
          ),

          SizedBox(height: 2.h),

          // Secondary Actions
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextButton.icon(
                onPressed: () {
                  Navigator.pushNamed(context, '/music-library');
                },
                icon: CustomIconWidget(
                  iconName: 'library_music',
                  color: AppTheme.lightTheme.colorScheme.secondary,
                  size: 18,
                ),
                label: Text(
                  'Jelajahi Musik',
                  style: TextStyle(
                    color: AppTheme.lightTheme.colorScheme.secondary,
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 2.w),
                width: 1,
                height: 4.h,
                color: AppTheme.lightTheme.dividerColor,
              ),
              TextButton.icon(
                onPressed: () {
                  Navigator.pushNamed(context, '/playlists');
                },
                icon: CustomIconWidget(
                  iconName: 'playlist_play',
                  color: AppTheme.lightTheme.colorScheme.secondary,
                  size: 18,
                ),
                label: Text(
                  'Playlist Lain',
                  style: TextStyle(
                    color: AppTheme.lightTheme.colorScheme.secondary,
                  ),
                ),
              ),
            ],
          ),

          SizedBox(height: 8.h),
        ],
      ),
    );
  }
}

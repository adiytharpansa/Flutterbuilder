import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class PlaylistHeaderWidget extends StatefulWidget {
  final Map<String, dynamic> playlistData;
  final String playlistName;
  final Function(String) onNameChanged;

  const PlaylistHeaderWidget({
    super.key,
    required this.playlistData,
    required this.playlistName,
    required this.onNameChanged,
  });

  @override
  State<PlaylistHeaderWidget> createState() => _PlaylistHeaderWidgetState();
}

class _PlaylistHeaderWidgetState extends State<PlaylistHeaderWidget> {
  final TextEditingController _nameController = TextEditingController();
  bool _isEditingName = false;

  @override
  void initState() {
    super.initState();
    _nameController.text = widget.playlistName;
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  void _startEditingName() {
    setState(() {
      _isEditingName = true;
    });
  }

  void _finishEditingName() {
    setState(() {
      _isEditingName = false;
      widget.onNameChanged(_nameController.text);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4.w),
      child: Column(
        children: [
          // Playlist Artwork
          Container(
            width: 50.w,
            height: 50.w,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.lightTheme.colorScheme.shadow
                      .withValues(alpha: 0.2),
                  blurRadius: 20,
                  offset: Offset(0, 8),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: CustomImageWidget(
                imageUrl: widget.playlistData["artwork"] as String,
                width: 50.w,
                height: 50.w,
                fit: BoxFit.cover,
              ),
            ),
          ),

          SizedBox(height: 3.h),

          // Playlist Name
          _isEditingName
              ? Container(
                  constraints: BoxConstraints(maxWidth: 80.w),
                  child: TextField(
                    controller: _nameController,
                    textAlign: TextAlign.center,
                    style:
                        AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(horizontal: 4.w),
                    ),
                    onSubmitted: (_) => _finishEditingName(),
                    autofocus: true,
                  ),
                )
              : GestureDetector(
                  onTap: _startEditingName,
                  child: Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                    child: Text(
                      widget.playlistName,
                      style:
                          AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),

          SizedBox(height: 1.h),

          // Playlist Info
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                '${widget.playlistData["trackCount"]} lagu',
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 2.w),
                width: 4,
                height: 4,
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  shape: BoxShape.circle,
                ),
              ),
              Text(
                widget.playlistData["totalDuration"] as String,
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

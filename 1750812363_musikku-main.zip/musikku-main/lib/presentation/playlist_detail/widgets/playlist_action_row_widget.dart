import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class PlaylistActionRowWidget extends StatelessWidget {
  final VoidCallback onPlayAll;
  final VoidCallback onShuffle;
  final VoidCallback onEdit;
  final bool isEditMode;

  const PlaylistActionRowWidget({
    super.key,
    required this.onPlayAll,
    required this.onShuffle,
    required this.onEdit,
    required this.isEditMode,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      child: Row(
        children: [
          // Play All Button
          Expanded(
            child: ElevatedButton.icon(
              onPressed: onPlayAll,
              icon: CustomIconWidget(
                iconName: 'play_arrow',
                color: AppTheme.lightTheme.colorScheme.onSecondary,
                size: 20,
              ),
              label: Text(
                'Putar Semua',
                style: AppTheme.lightTheme.textTheme.labelLarge?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSecondary,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
                foregroundColor: AppTheme.lightTheme.colorScheme.onSecondary,
                padding: EdgeInsets.symmetric(vertical: 1.5.h),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25),
                ),
              ),
            ),
          ),

          SizedBox(width: 3.w),

          // Shuffle Button
          Container(
            decoration: BoxDecoration(
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline,
                width: 1,
              ),
              borderRadius: BorderRadius.circular(25),
            ),
            child: IconButton(
              onPressed: onShuffle,
              icon: CustomIconWidget(
                iconName: 'shuffle',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 20,
              ),
              padding: EdgeInsets.all(1.5.h),
            ),
          ),

          SizedBox(width: 3.w),

          // More Options Button
          Container(
            decoration: BoxDecoration(
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline,
                width: 1,
              ),
              borderRadius: BorderRadius.circular(25),
            ),
            child: IconButton(
              onPressed: () => _showMoreOptions(context),
              icon: CustomIconWidget(
                iconName: 'more_vert',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 20,
              ),
              padding: EdgeInsets.all(1.5.h),
            ),
          ),
        ],
      ),
    );
  }

  void _showMoreOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: EdgeInsets.symmetric(vertical: 2.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.outline,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 2.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'add',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 24,
              ),
              title: Text('Tambah Lagu'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/music-library');
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'download',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 24,
              ),
              title: Text('Download Playlist'),
              onTap: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Mengunduh playlist...')),
                );
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'share',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 24,
              ),
              title: Text('Bagikan Playlist'),
              onTap: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Membagikan playlist...')),
                );
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'sort',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 24,
              ),
              title: Text('Urutkan'),
              onTap: () {
                Navigator.pop(context);
                _showSortOptions(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showSortOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: EdgeInsets.symmetric(vertical: 2.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
              child: Text(
                'Urutkan berdasarkan',
                style: AppTheme.lightTheme.textTheme.titleMedium,
              ),
            ),
            ListTile(
              title: Text('Urutan Manual'),
              trailing: CustomIconWidget(
                iconName: 'check',
                color: AppTheme.lightTheme.colorScheme.secondary,
                size: 20,
              ),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              title: Text('Judul'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              title: Text('Artis'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              title: Text('Durasi'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              title: Text('Terakhir Ditambahkan'),
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
    );
  }
}

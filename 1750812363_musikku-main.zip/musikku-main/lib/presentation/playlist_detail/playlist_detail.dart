import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/empty_playlist_widget.dart';
import './widgets/playlist_action_row_widget.dart';
import './widgets/playlist_header_widget.dart';
import './widgets/track_list_widget.dart';

class PlaylistDetail extends StatefulWidget {
  const PlaylistDetail({super.key});

  @override
  State<PlaylistDetail> createState() => _PlaylistDetailState();
}

class _PlaylistDetailState extends State<PlaylistDetail>
    with TickerProviderStateMixin {
  final ScrollController _scrollController = ScrollController();
  final TextEditingController _searchController = TextEditingController();
  bool _isEditMode = false;
  bool _isSearchVisible = false;
  final List<int> _selectedTracks = [];
  String _playlistName = "My Favorites";

  // Mock playlist data
  final Map<String, dynamic> _playlistData = {
    "id": 1,
    "name": "My Favorites",
    "artwork":
        "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=400&fit=crop",
    "trackCount": 15,
    "totalDuration": "1h 23m",
    "tracks": [
      {
        "id": 1,
        "title": "Bohemian Rhapsody",
        "artist": "Queen",
        "duration": "5:55",
        "artwork":
            "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=60&h=60&fit=crop",
        "isPlaying": false,
      },
      {
        "id": 2,
        "title": "Hotel California",
        "artist": "Eagles",
        "duration": "6:30",
        "artwork":
            "https://images.unsplash.com/photo-1514320291840-2e0a9bf2a9ae?w=60&h=60&fit=crop",
        "isPlaying": true,
      },
      {
        "id": 3,
        "title": "Stairway to Heaven",
        "artist": "Led Zeppelin",
        "duration": "8:02",
        "artwork":
            "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=60&h=60&fit=crop",
        "isPlaying": false,
      },
      {
        "id": 4,
        "title": "Sweet Child O' Mine",
        "artist": "Guns N' Roses",
        "duration": "5:03",
        "artwork":
            "https://images.unsplash.com/photo-1514320291840-2e0a9bf2a9ae?w=60&h=60&fit=crop",
        "isPlaying": false,
      },
      {
        "id": 5,
        "title": "Imagine",
        "artist": "John Lennon",
        "duration": "3:07",
        "artwork":
            "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=60&h=60&fit=crop",
        "isPlaying": false,
      },
    ]
  };

  List<Map<String, dynamic>> _filteredTracks = [];

  @override
  void initState() {
    super.initState();
    _filteredTracks = List.from(_playlistData["tracks"] as List);
    _playlistName = _playlistData["name"] as String;
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _toggleEditMode() {
    setState(() {
      _isEditMode = !_isEditMode;
      if (!_isEditMode) {
        _selectedTracks.clear();
      }
    });
  }

  void _toggleSearch() {
    setState(() {
      _isSearchVisible = !_isSearchVisible;
      if (!_isSearchVisible) {
        _searchController.clear();
        _filteredTracks = List.from(_playlistData["tracks"] as List);
      }
    });
  }

  void _filterTracks(String query) {
    setState(() {
      if (query.isEmpty) {
        _filteredTracks = List.from(_playlistData["tracks"] as List);
      } else {
        _filteredTracks = (_playlistData["tracks"] as List)
            .where((track) =>
                (track["title"] as String)
                    .toLowerCase()
                    .contains(query.toLowerCase()) ||
                (track["artist"] as String)
                    .toLowerCase()
                    .contains(query.toLowerCase()))
            .cast<Map<String, dynamic>>()
            .toList();
      }
    });
  }

  void _toggleTrackSelection(int trackId) {
    setState(() {
      if (_selectedTracks.contains(trackId)) {
        _selectedTracks.remove(trackId);
      } else {
        _selectedTracks.add(trackId);
      }
    });
  }

  void _removeSelectedTracks() {
    if (_selectedTracks.isEmpty) return;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Remove Tracks'),
        content:
            Text('Remove \${_selectedTracks.length} track(s) from playlist?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                (_playlistData["tracks"] as List).removeWhere(
                  (track) => _selectedTracks.contains(track["id"]),
                );
                _filteredTracks = List.from(_playlistData["tracks"] as List);
                _selectedTracks.clear();
                _isEditMode = false;
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Tracks removed from playlist'),
                  action: SnackBarAction(
                    label: 'Undo',
                    onPressed: () {
                      // Undo functionality would be implemented here
                    },
                  ),
                ),
              );
            },
            child: Text('Remove'),
          ),
        ],
      ),
    );
  }

  void _updatePlaylistName(String newName) {
    setState(() {
      _playlistName = newName;
      _playlistData["name"] = newName;
    });
  }

  @override
  Widget build(BuildContext context) {
    final tracks = _filteredTracks;
    final isEmpty = tracks.isEmpty && !_isSearchVisible;

    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            // Custom App Bar
            Container(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: EdgeInsets.all(2.w),
                      child: CustomIconWidget(
                        iconName: 'arrow_back',
                        color: AppTheme.lightTheme.colorScheme.onSurface,
                        size: 24,
                      ),
                    ),
                  ),
                  Spacer(),
                  GestureDetector(
                    onTap: _toggleSearch,
                    child: Container(
                      padding: EdgeInsets.all(2.w),
                      child: CustomIconWidget(
                        iconName: 'search',
                        color: AppTheme.lightTheme.colorScheme.onSurface,
                        size: 24,
                      ),
                    ),
                  ),
                  SizedBox(width: 2.w),
                  GestureDetector(
                    onTap: _toggleEditMode,
                    child: Container(
                      padding: EdgeInsets.all(2.w),
                      child: CustomIconWidget(
                        iconName: _isEditMode ? 'done' : 'edit',
                        color: _isEditMode
                            ? AppTheme.lightTheme.colorScheme.secondary
                            : AppTheme.lightTheme.colorScheme.onSurface,
                        size: 24,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Search Bar
            if (_isSearchVisible)
              Container(
                margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                child: TextField(
                  controller: _searchController,
                  onChanged: _filterTracks,
                  decoration: InputDecoration(
                    hintText: 'Search in playlist...',
                    prefixIcon: CustomIconWidget(
                      iconName: 'search',
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      size: 20,
                    ),
                    suffixIcon: _searchController.text.isNotEmpty
                        ? GestureDetector(
                            onTap: () {
                              _searchController.clear();
                              _filterTracks('');
                            },
                            child: CustomIconWidget(
                              iconName: 'clear',
                              color: AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                              size: 20,
                            ),
                          )
                        : null,
                  ),
                ),
              ),

            // Content
            Expanded(
              child: isEmpty
                  ? EmptyPlaylistWidget(
                      onAddSongs: () {
                        Navigator.pushNamed(context, '/music-library');
                      },
                    )
                  : RefreshIndicator(
                      onRefresh: () async {
                        // Simulate refresh
                        await Future.delayed(Duration(seconds: 1));
                      },
                      child: CustomScrollView(
                        controller: _scrollController,
                        slivers: [
                          // Playlist Header
                          SliverToBoxAdapter(
                            child: PlaylistHeaderWidget(
                              playlistData: _playlistData,
                              playlistName: _playlistName,
                              onNameChanged: _updatePlaylistName,
                            ),
                          ),

                          // Action Row
                          SliverToBoxAdapter(
                            child: PlaylistActionRowWidget(
                              onPlayAll: () {
                                Navigator.pushNamed(context, '/now-playing');
                              },
                              onShuffle: () {
                                Navigator.pushNamed(context, '/now-playing');
                              },
                              onEdit: _toggleEditMode,
                              isEditMode: _isEditMode,
                            ),
                          ),

                          // Track List
                          SliverToBoxAdapter(
                            child: TrackListWidget(
                              tracks: tracks,
                              isEditMode: _isEditMode,
                              selectedTracks: _selectedTracks,
                              onTrackTap: (track) {
                                if (_isEditMode) {
                                  _toggleTrackSelection(track["id"] as int);
                                } else {
                                  Navigator.pushNamed(context, '/now-playing');
                                }
                              },
                              onTrackLongPress: (track) {
                                if (!_isEditMode) {
                                  _showTrackContextMenu(track);
                                }
                              },
                              onRemoveTrack: (track) {
                                _removeTrackFromPlaylist(track);
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
            ),

            // Bottom Action Bar (Edit Mode)
            if (_isEditMode && _selectedTracks.isNotEmpty)
              Container(
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.surface,
                  border: Border(
                    top: BorderSide(
                      color: AppTheme.lightTheme.dividerColor,
                      width: 1,
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    Text(
                      '\${_selectedTracks.length} selected',
                      style: AppTheme.lightTheme.textTheme.bodyMedium,
                    ),
                    Spacer(),
                    TextButton.icon(
                      onPressed: _removeSelectedTracks,
                      icon: CustomIconWidget(
                        iconName: 'delete',
                        color: AppTheme.lightTheme.colorScheme.error,
                        size: 20,
                      ),
                      label: Text(
                        'Remove',
                        style: TextStyle(
                          color: AppTheme.lightTheme.colorScheme.error,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  void _showTrackContextMenu(Map<String, dynamic> track) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: EdgeInsets.symmetric(vertical: 2.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Track Info
            Container(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: CustomImageWidget(
                      imageUrl: track["artwork"] as String,
                      width: 50,
                      height: 50,
                      fit: BoxFit.cover,
                    ),
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          track["title"] as String,
                          style: AppTheme.lightTheme.textTheme.titleMedium,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          track["artist"] as String,
                          style: AppTheme.lightTheme.textTheme.bodySmall,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Divider(),
            // Menu Options
            ListTile(
              leading: CustomIconWidget(
                iconName: 'play_arrow',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 24,
              ),
              title: Text('Play Next'),
              onTap: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Added to play next')),
                );
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'vertical_align_top',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 24,
              ),
              title: Text('Move to Top'),
              onTap: () {
                Navigator.pop(context);
                // Move track to top logic
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'info',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 24,
              ),
              title: Text('Song Info'),
              onTap: () {
                Navigator.pop(context);
                // Show song info dialog
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'remove_circle_outline',
                color: AppTheme.lightTheme.colorScheme.error,
                size: 24,
              ),
              title: Text(
                'Remove from Playlist',
                style: TextStyle(
                  color: AppTheme.lightTheme.colorScheme.error,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                _removeTrackFromPlaylist(track);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _removeTrackFromPlaylist(Map<String, dynamic> track) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Remove Track'),
        content: Text('Remove "${track["title"]}" from playlist?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                (_playlistData["tracks"] as List).removeWhere(
                  (t) => t["id"] == track["id"],
                );
                _filteredTracks = List.from(_playlistData["tracks"] as List);
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Track removed from playlist'),
                  action: SnackBarAction(
                    label: 'Undo',
                    onPressed: () {
                      // Undo functionality would be implemented here
                    },
                  ),
                ),
              );
            },
            child: Text('Remove'),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/empty_state_widget.dart';
import './widgets/filter_chip_widget.dart';
import './widgets/song_list_item_widget.dart';

class MusicLibrary extends StatefulWidget {
  const MusicLibrary({super.key});

  @override
  State<MusicLibrary> createState() => _MusicLibraryState();
}

class _MusicLibraryState extends State<MusicLibrary>
    with TickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _searchController = TextEditingController();
  final bool _isGridView = false;
  String _selectedFilter = 'All Songs';
  final bool _isSearching = false;
  List<Map<String, dynamic>> _filteredSongs = [];

  final List<String> _filterCategories = [
    'All Songs',
    'Artists',
    'Albums',
    'Genres'
  ];

  final List<Map<String, dynamic>> _mockSongs = [
    {
      "id": 1,
      "title": "Bohemian Rhapsody",
      "artist": "Queen",
      "album": "A Night at the Opera",
      "duration": "5:55",
      "artwork":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
      "isFavorite": true,
      "genre": "Rock"
    },
    {
      "id": 2,
      "title": "Hotel California",
      "artist": "Eagles",
      "album": "Hotel California",
      "duration": "6:30",
      "artwork":
          "https://images.pexels.com/photos/164745/pexels-photo-164745.jpeg?w=300&h=300&fit=crop",
      "isFavorite": false,
      "genre": "Rock"
    },
    {
      "id": 3,
      "title": "Imagine",
      "artist": "John Lennon",
      "album": "Imagine",
      "duration": "3:07",
      "artwork":
          "https://images.pixabay.com/photo/2016/11/29/05/45/astronomy-1867616_1280.jpg?w=300&h=300&fit=crop",
      "isFavorite": true,
      "genre": "Pop"
    },
    {
      "id": 4,
      "title": "Stairway to Heaven",
      "artist": "Led Zeppelin",
      "album": "Led Zeppelin IV",
      "duration": "8:02",
      "artwork":
          "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=300&h=300&fit=crop",
      "isFavorite": false,
      "genre": "Rock"
    },
    {
      "id": 5,
      "title": "Billie Jean",
      "artist": "Michael Jackson",
      "album": "Thriller",
      "duration": "4:54",
      "artwork":
          "https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?w=300&h=300&fit=crop",
      "isFavorite": true,
      "genre": "Pop"
    },
    {
      "id": 6,
      "title": "Sweet Child O' Mine",
      "artist": "Guns N' Roses",
      "album": "Appetite for Destruction",
      "duration": "5:03",
      "artwork":
          "https://images.pixabay.com/photo/2015/05/07/13/46/guitar-756326_1280.jpg?w=300&h=300&fit=crop",
      "isFavorite": false,
      "genre": "Rock"
    },
    {
      "id": 7,
      "title": "Like a Rolling Stone",
      "artist": "Bob Dylan",
      "album": "Highway 61 Revisited",
      "duration": "6:13",
      "artwork":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
      "isFavorite": false,
      "genre": "Folk"
    },
    {
      "id": 8,
      "title": "Smells Like Teen Spirit",
      "artist": "Nirvana",
      "album": "Nevermind",
      "duration": "5:01",
      "artwork":
          "https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?w=300&h=300&fit=crop",
      "isFavorite": true,
      "genre": "Grunge"
    }
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _filteredSongs = List.from(_mockSongs);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _filterSongs(String query) {
    setState(() {
      if (query.isEmpty) {
        _filteredSongs = List.from(_mockSongs);
      } else {
        _filteredSongs = _mockSongs
            .where((song) =>
                (song['title'] as String)
                    .toLowerCase()
                    .contains(query.toLowerCase()) ||
                (song['artist'] as String)
                    .toLowerCase()
                    .contains(query.toLowerCase()) ||
                (song['album'] as String)
                    .toLowerCase()
                    .contains(query.toLowerCase()))
            .toList();
      }
    });
  }

  void _filterByCategory(String category) {
    setState(() {
      _selectedFilter = category;
      if (category == 'All Songs') {
        _filteredSongs = List.from(_mockSongs);
      } else {
        // For demo purposes, showing all songs for other categories
        _filteredSongs = List.from(_mockSongs);
      }
    });
  }

  void _toggleFavorite(int songId) {
    setState(() {
      final songIndex = _mockSongs.indexWhere((song) => song['id'] == songId);
      if (songIndex != -1) {
        _mockSongs[songIndex]['isFavorite'] =
            !(_mockSongs[songIndex]['isFavorite'] as bool);
      }
      _filterSongs(_searchController.text);
    });
  }

  void _showSongOptions(BuildContext context, Map<String, dynamic> song) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40.w,
              height: 0.5.h,
              margin: EdgeInsets.symmetric(vertical: 1.h),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(4.w),
              child: Column(
                children: [
                  Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: CustomImageWidget(
                          imageUrl: song['artwork'] as String,
                          width: 15.w,
                          height: 15.w,
                          fit: BoxFit.cover,
                        ),
                      ),
                      SizedBox(width: 3.w),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              song['title'] as String,
                              style: AppTheme.lightTheme.textTheme.titleMedium,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text(
                              song['artist'] as String,
                              style: AppTheme.lightTheme.textTheme.bodySmall,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 3.h),
                  _buildOptionItem('Play Next', 'skip_next'),
                  _buildOptionItem('Add to Queue', 'queue_music'),
                  _buildOptionItem('Add to Playlist', 'playlist_add'),
                  _buildOptionItem('Song Info', 'info'),
                  _buildOptionItem('Delete', 'delete', isDestructive: true),
                  SizedBox(height: 2.h),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOptionItem(String title, String iconName,
      {bool isDestructive = false}) {
    return ListTile(
      leading: CustomIconWidget(
        iconName: iconName,
        color: isDestructive
            ? AppTheme.lightTheme.colorScheme.error
            : AppTheme.lightTheme.colorScheme.onSurface,
        size: 24,
      ),
      title: Text(
        title,
        style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
          color: isDestructive
              ? AppTheme.lightTheme.colorScheme.error
              : AppTheme.lightTheme.colorScheme.onSurface,
        ),
      ),
      onTap: () {
        Navigator.pop(context);
        // Handle option selection
      },
    );
  }

  Future<void> _refreshMusic() async {
    // Simulate refresh delay
    await Future.delayed(const Duration(seconds: 1));
    setState(() {
      // In real app, this would rescan music directory
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            // Header with search and view toggle
            Container(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surface,
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.lightTheme.shadowColor,
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  // Search bar
                  Container(
                    height: 6.h,
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.colorScheme.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: AppTheme.lightTheme.colorScheme.outline,
                      ),
                    ),
                    child: TextField(
                      controller: _searchController,
                      onChanged: _filterSongs,
                      decoration: InputDecoration(
                        hintText: 'Cari musik...',
                        hintStyle:
                            AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                          color:
                              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        ),
                        prefixIcon: Padding(
                          padding: EdgeInsets.all(3.w),
                          child: CustomIconWidget(
                            iconName: 'search',
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                            size: 20,
                          ),
                        ),
                        suffixIcon: _searchController.text.isNotEmpty
                            ? IconButton(
                                onPressed: () {
                                  _searchController.clear();
                                  _filterSongs('');
                                },
                                icon: CustomIconWidget(
                                  iconName: 'clear',
                                  color: AppTheme
                                      .lightTheme.colorScheme.onSurfaceVariant,
                                  size: 20,
                                ),
                              )
                            : Padding(
                                padding: EdgeInsets.all(3.w),
                                child: CustomIconWidget(
                                  iconName: _isGridView ? 'list' : 'grid_view',
                                  color: AppTheme
                                      .lightTheme.colorScheme.onSurfaceVariant,
                                  size: 20,
                                ),
                              ),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 4.w,
                          vertical: 1.5.h,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 2.h),
                  // Filter chips
                  SizedBox(
                    height: 5.h,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: _filterCategories.length,
                      itemBuilder: (context, index) {
                        return FilterChipWidget(
                          label: _filterCategories[index],
                          isSelected:
                              _selectedFilter == _filterCategories[index],
                          onTap: () =>
                              _filterByCategory(_filterCategories[index]),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            // Tab bar
            Container(
              color: AppTheme.lightTheme.colorScheme.surface,
              child: TabBar(
                controller: _tabController,
                tabs: const [
                  Tab(text: 'Library'),
                  Tab(text: 'Playlists'),
                  Tab(text: 'Now Playing'),
                  Tab(text: 'Settings'),
                ],
              ),
            ),
            // Content
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  // Library tab content
                  _filteredSongs.isEmpty
                      ? const EmptyStateWidget()
                      : RefreshIndicator(
                          onRefresh: _refreshMusic,
                          color: AppTheme.lightTheme.colorScheme.secondary,
                          child: ListView.builder(
                            padding: EdgeInsets.symmetric(vertical: 1.h),
                            itemCount: _filteredSongs.length,
                            itemBuilder: (context, index) {
                              final song = _filteredSongs[index];
                              return SongListItemWidget(
                                song: song,
                                onTap: () {
                                  Navigator.pushNamed(context, '/now-playing');
                                },
                                onLongPress: () =>
                                    _showSongOptions(context, song),
                                onFavoriteToggle: () =>
                                    _toggleFavorite(song['id'] as int),
                              );
                            },
                          ),
                        ),
                  // Other tabs
                  Center(
                    child: TextButton(
                      onPressed: () =>
                          Navigator.pushNamed(context, '/playlists'),
                      child: Text('Go to Playlists'),
                    ),
                  ),
                  Center(
                    child: TextButton(
                      onPressed: () =>
                          Navigator.pushNamed(context, '/now-playing'),
                      child: Text('Go to Now Playing'),
                    ),
                  ),
                  Center(
                    child: TextButton(
                      onPressed: () =>
                          Navigator.pushNamed(context, '/settings'),
                      child: Text('Go to Settings'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

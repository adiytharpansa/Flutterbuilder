import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/create_playlist_bottom_sheet.dart';
import './widgets/playlist_card_widget.dart';

class Playlists extends StatefulWidget {
  const Playlists({super.key});

  @override
  State<Playlists> createState() => _PlaylistsState();
}

class _PlaylistsState extends State<Playlists> with TickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  bool _isSearching = false;

  // Mock playlist data
  final List<Map<String, dynamic>> _playlists = [
    {
      "id": 1,
      "name": "Favorit Saya",
      "trackCount": 24,
      "duration": "1j 32m",
      "coverArt":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
      "isRecent": true,
      "createdDate": DateTime.now().subtract(Duration(days: 2)),
      "songs": [
        {"title": "Dewa 19 - Kangen", "artist": "Dewa 19"},
        {"title": "Sheila On 7 - Dan", "artist": "Sheila On 7"},
      ]
    },
    {
      "id": 2,
      "name": "Lagu Indonesia",
      "trackCount": 45,
      "duration": "2j 48m",
      "coverArt":
          "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&h=300&fit=crop",
      "isRecent": true,
      "createdDate": DateTime.now().subtract(Duration(days: 5)),
      "songs": [
        {"title": "Iwan Fals - Bento", "artist": "Iwan Fals"},
        {"title": "Chrisye - Badai Pasti Berlalu", "artist": "Chrisye"},
      ]
    },
    {
      "id": 3,
      "name": "Rock Klasik",
      "trackCount": 18,
      "duration": "1j 15m",
      "coverArt":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
      "isRecent": false,
      "createdDate": DateTime.now().subtract(Duration(days: 15)),
      "songs": [
        {"title": "God Bless - Rumah Kita", "artist": "God Bless"},
        {"title": "Slank - Terlalu Manis", "artist": "Slank"},
      ]
    },
    {
      "id": 4,
      "name": "Pop Indonesia",
      "trackCount": 32,
      "duration": "2j 5m",
      "coverArt":
          "https://images.unsplash.com/photo-1514320291840-2e0a9bf2a9ae?w=300&h=300&fit=crop",
      "isRecent": false,
      "createdDate": DateTime.now().subtract(Duration(days: 30)),
      "songs": [
        {"title": "Raisa - Serba Salah", "artist": "Raisa"},
        {"title": "Afgan - Sadis", "artist": "Afgan"},
      ]
    },
  ];

  List<Map<String, dynamic>> get _filteredPlaylists {
    if (_searchQuery.isEmpty) {
      return _playlists;
    }
    return _playlists
        .where((playlist) => (playlist["name"] as String)
            .toLowerCase()
            .contains(_searchQuery.toLowerCase()))
        .toList();
  }

  List<Map<String, dynamic>> get _recentPlaylists {
    return _filteredPlaylists
        .where((playlist) => playlist["isRecent"] == true)
        .toList();
  }

  List<Map<String, dynamic>> get _allPlaylists {
    return _filteredPlaylists
        .where((playlist) => playlist["isRecent"] != true)
        .toList();
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this, initialIndex: 1);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _showCreatePlaylistBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => CreatePlaylistBottomSheet(
        onPlaylistCreated: (String playlistName) {
          setState(() {
            _playlists.insert(0, {
              "id": _playlists.length + 1,
              "name": playlistName,
              "trackCount": 0,
              "duration": "0m",
              "coverArt":
                  "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
              "isRecent": true,
              "createdDate": DateTime.now(),
              "songs": [],
            });
          });
        },
      ),
    );
  }

  void _showPlaylistOptions(Map<String, dynamic> playlist) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              margin: EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'play_arrow',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 24,
              ),
              title:
                  Text('Putar', style: AppTheme.lightTheme.textTheme.bodyLarge),
              onTap: () {
                Navigator.pop(context);
                // Handle play action
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'shuffle',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 24,
              ),
              title:
                  Text('Acak', style: AppTheme.lightTheme.textTheme.bodyLarge),
              onTap: () {
                Navigator.pop(context);
                // Handle shuffle action
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'edit',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 24,
              ),
              title:
                  Text('Edit', style: AppTheme.lightTheme.textTheme.bodyLarge),
              onTap: () {
                Navigator.pop(context);
                // Handle edit action
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'share',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 24,
              ),
              title: Text('Bagikan',
                  style: AppTheme.lightTheme.textTheme.bodyLarge),
              onTap: () {
                Navigator.pop(context);
                // Handle share action
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'delete',
                color: AppTheme.lightTheme.colorScheme.error,
                size: 24,
              ),
              title: Text('Hapus',
                  style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.error,
                  )),
              onTap: () {
                Navigator.pop(context);
                _deletePlaylist(playlist["id"]);
              },
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  void _deletePlaylist(int playlistId) {
    setState(() {
      _playlists.removeWhere((playlist) => playlist["id"] == playlistId);
    });
  }

  Future<void> _refreshPlaylists() async {
    await Future.delayed(Duration(seconds: 1));
    // Simulate refresh - in real app, this would reload from storage
    setState(() {});
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: 'queue_music',
            color: AppTheme.lightTheme.colorScheme.onSurface
                .withValues(alpha: 0.5),
            size: 80,
          ),
          SizedBox(height: 3.h),
          Text(
            'Belum Ada Playlist',
            style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurface
                  .withValues(alpha: 0.7),
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'Buat playlist pertama Anda untuk\nmengorganisir musik favorit',
            textAlign: TextAlign.center,
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurface
                  .withValues(alpha: 0.6),
            ),
          ),
          SizedBox(height: 4.h),
          ElevatedButton.icon(
            onPressed: _showCreatePlaylistBottomSheet,
            icon: CustomIconWidget(
              iconName: 'add',
              color: AppTheme.lightTheme.colorScheme.onSecondary,
              size: 20,
            ),
            label: Text('Buat Playlist Pertama'),
            style: AppTheme.lightTheme.elevatedButtonTheme.style,
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.3),
        ),
      ),
      child: TextField(
        controller: _searchController,
        onChanged: (value) {
          setState(() {
            _searchQuery = value;
            _isSearching = value.isNotEmpty;
          });
        },
        decoration: InputDecoration(
          hintText: 'Cari playlist...',
          prefixIcon: Padding(
            padding: EdgeInsets.all(12),
            child: CustomIconWidget(
              iconName: 'search',
              color: AppTheme.lightTheme.colorScheme.onSurface
                  .withValues(alpha: 0.6),
              size: 20,
            ),
          ),
          suffixIcon: _isSearching
              ? IconButton(
                  onPressed: () {
                    _searchController.clear();
                    setState(() {
                      _searchQuery = '';
                      _isSearching = false;
                    });
                  },
                  icon: CustomIconWidget(
                    iconName: 'clear',
                    color: AppTheme.lightTheme.colorScheme.onSurface
                        .withValues(alpha: 0.6),
                    size: 20,
                  ),
                )
              : null,
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        ),
        style: AppTheme.lightTheme.textTheme.bodyMedium,
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Playlist Saya',
            style: AppTheme.lightTheme.textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          ElevatedButton.icon(
            onPressed: _showCreatePlaylistBottomSheet,
            icon: CustomIconWidget(
              iconName: 'add',
              color: AppTheme.lightTheme.colorScheme.onSecondary,
              size: 18,
            ),
            label: Text('Baru'),
            style: AppTheme.lightTheme.elevatedButtonTheme.style?.copyWith(
              padding: WidgetStateProperty.all(
                EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlaylistSection(
      String title, List<Map<String, dynamic>> playlists) {
    if (playlists.isEmpty) return SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          child: Text(
            title,
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        ListView.builder(
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
          itemCount: playlists.length,
          itemBuilder: (context, index) {
            final playlist = playlists[index];
            return PlaylistCardWidget(
              playlist: playlist,
              onTap: () {
                Navigator.pushNamed(context, '/playlist-detail',
                    arguments: playlist);
              },
              onLongPress: () {
                _showPlaylistOptions(playlist);
              },
            );
          },
        ),
        SizedBox(height: 2.h),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            // Tab Bar
            Container(
              color: AppTheme.lightTheme.scaffoldBackgroundColor,
              child: TabBar(
                controller: _tabController,
                tabs: [
                  Tab(text: 'Perpustakaan'),
                  Tab(text: 'Playlist'),
                  Tab(text: 'Sedang Diputar'),
                  Tab(text: 'Pengaturan'),
                ],
                onTap: (index) {
                  switch (index) {
                    case 0:
                      Navigator.pushReplacementNamed(context, '/music-library');
                      break;
                    case 1:
                      // Already on playlists
                      break;
                    case 2:
                      Navigator.pushReplacementNamed(context, '/now-playing');
                      break;
                    case 3:
                      Navigator.pushReplacementNamed(context, '/settings');
                      break;
                  }
                },
              ),
            ),

            // Content
            Expanded(
              child: _filteredPlaylists.isEmpty && _searchQuery.isEmpty
                  ? _buildEmptyState()
                  : RefreshIndicator(
                      onRefresh: _refreshPlaylists,
                      color: AppTheme.lightTheme.colorScheme.secondary,
                      child: SingleChildScrollView(
                        physics: AlwaysScrollableScrollPhysics(),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildHeader(),
                            _buildSearchBar(),

                            if (_filteredPlaylists.isEmpty &&
                                _searchQuery.isNotEmpty)
                              SizedBox(
                                height: 40.h,
                                child: Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      CustomIconWidget(
                                        iconName: 'search_off',
                                        color: AppTheme
                                            .lightTheme.colorScheme.onSurface
                                            .withValues(alpha: 0.5),
                                        size: 60,
                                      ),
                                      SizedBox(height: 2.h),
                                      Text(
                                        'Tidak ada playlist ditemukan',
                                        style: AppTheme
                                            .lightTheme.textTheme.titleMedium
                                            ?.copyWith(
                                          color: AppTheme
                                              .lightTheme.colorScheme.onSurface
                                              .withValues(alpha: 0.7),
                                        ),
                                      ),
                                      SizedBox(height: 1.h),
                                      Text(
                                        'Coba kata kunci lain',
                                        style: AppTheme
                                            .lightTheme.textTheme.bodyMedium
                                            ?.copyWith(
                                          color: AppTheme
                                              .lightTheme.colorScheme.onSurface
                                              .withValues(alpha: 0.6),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              )
                            else ...[
                              _buildPlaylistSection(
                                  'Terbaru', _recentPlaylists),
                              _buildPlaylistSection(
                                  'Semua Playlist', _allPlaylists),
                            ],

                            SizedBox(height: 10.h), // Bottom padding for FAB
                          ],
                        ),
                      ),
                    ),
            ),
          ],
        ),
      ),
      floatingActionButton: _filteredPlaylists.isNotEmpty
          ? FloatingActionButton(
              onPressed: _showCreatePlaylistBottomSheet,
              backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
              child: CustomIconWidget(
                iconName: 'add',
                color: AppTheme.lightTheme.colorScheme.onSecondary,
                size: 24,
              ),
            )
          : null,
    );
  }
}

import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/album_artwork_widget.dart';
import './widgets/bottom_actions_widget.dart';
import './widgets/playback_controls_widget.dart';
import './widgets/progress_slider_widget.dart';
import './widgets/secondary_controls_widget.dart';
import './widgets/track_info_widget.dart';
import './widgets/volume_control_widget.dart';

class NowPlaying extends StatefulWidget {
  const NowPlaying({super.key});

  @override
  State<NowPlaying> createState() => _NowPlayingState();
}

class _NowPlayingState extends State<NowPlaying> with TickerProviderStateMixin {
  late AnimationController _rotationController;
  late AnimationController _fadeController;

  bool isPlaying = true;
  bool isFavorite = false;
  bool isShuffleOn = false;
  bool isRepeatOn = false;
  double currentPosition = 0.45;
  double volume = 0.7;
  bool showLyrics = false;

  // Mock current track data
  final Map<String, dynamic> currentTrack = {
    "id": 1,
    "title": "Bohemian Rhapsody",
    "artist": "Queen",
    "album": "A Night at the Opera",
    "duration": "5:55",
    "currentTime": "2:30",
    "albumArt":
        "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=500&h=500&fit=crop",
    "isFavorite": false,
  };

  @override
  void initState() {
    super.initState();
    _rotationController = AnimationController(
      duration: const Duration(seconds: 20),
      vsync: this,
    );
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    if (isPlaying) {
      _rotationController.repeat();
    }
    _fadeController.forward();
  }

  @override
  void dispose() {
    _rotationController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  void _togglePlayPause() {
    setState(() {
      isPlaying = !isPlaying;
      if (isPlaying) {
        _rotationController.repeat();
      } else {
        _rotationController.stop();
      }
    });
  }

  void _toggleFavorite() {
    setState(() {
      isFavorite = !isFavorite;
    });
  }

  void _toggleShuffle() {
    setState(() {
      isShuffleOn = !isShuffleOn;
    });
  }

  void _toggleRepeat() {
    setState(() {
      isRepeatOn = !isRepeatOn;
    });
  }

  void _onSeek(double value) {
    setState(() {
      currentPosition = value;
    });
  }

  void _onVolumeChange(double value) {
    setState(() {
      volume = value;
    });
  }

  void _showOptionsMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40.w,
              height: 0.5.h,
              margin: EdgeInsets.symmetric(vertical: 1.h),
              decoration: BoxDecoration(
                color: Theme.of(context).dividerColor,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'share',
                color: Theme.of(context).colorScheme.onSurface,
                size: 24,
              ),
              title: Text('Bagikan'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'playlist_add',
                color: Theme.of(context).colorScheme.onSurface,
                size: 24,
              ),
              title: Text('Tambah ke Playlist'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'info',
                color: Theme.of(context).colorScheme.onSurface,
                size: 24,
              ),
              title: Text('Info Lagu'),
              onTap: () => Navigator.pop(context),
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: NetworkImage(currentTrack["albumArt"] as String),
            fit: BoxFit.cover,
          ),
        ),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withValues(alpha: 0.3),
                Colors.black.withValues(alpha: 0.7),
                Colors.black.withValues(alpha: 0.9),
              ],
            ),
          ),
          child: SafeArea(
            child: FadeTransition(
              opacity: _fadeController,
              child: Column(
                children: [
                  // Top App Bar
                  Padding(
                    padding:
                        EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Container(
                            padding: EdgeInsets.all(2.w),
                            decoration: BoxDecoration(
                              color: Colors.black.withValues(alpha: 0.3),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: CustomIconWidget(
                              iconName: 'keyboard_arrow_down',
                              color: Colors.white,
                              size: 24,
                            ),
                          ),
                        ),
                        Text(
                          'SEDANG DIPUTAR',
                          style:
                              Theme.of(context).textTheme.labelMedium?.copyWith(
                                    color: Colors.white.withValues(alpha: 0.8),
                                    letterSpacing: 1.2,
                                  ),
                        ),
                        GestureDetector(
                          onTap: _showOptionsMenu,
                          child: Container(
                            padding: EdgeInsets.all(2.w),
                            decoration: BoxDecoration(
                              color: Colors.black.withValues(alpha: 0.3),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: CustomIconWidget(
                              iconName: 'more_vert',
                              color: Colors.white,
                              size: 24,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: 4.h),

                  // Album Artwork
                  Expanded(
                    flex: 3,
                    child: AlbumArtworkWidget(
                      imageUrl: currentTrack["albumArt"] as String,
                      rotationController: _rotationController,
                      isPlaying: isPlaying,
                    ),
                  ),

                  SizedBox(height: 4.h),

                  // Track Info
                  Expanded(
                    flex: 2,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 6.w),
                      child: Column(
                        children: [
                          // Track Title and Artist
                          TrackInfoWidget(
                            title: currentTrack["title"] as String,
                            artist: currentTrack["artist"] as String,
                            isFavorite: isFavorite,
                            onFavoriteToggle: _toggleFavorite,
                          ),

                          SizedBox(height: 3.h),

                          // Progress Slider
                          ProgressSliderWidget(
                            currentPosition: currentPosition,
                            currentTime: currentTrack["currentTime"] as String,
                            duration: currentTrack["duration"] as String,
                            onSeek: _onSeek,
                          ),

                          SizedBox(height: 4.h),

                          // Playback Controls
                          PlaybackControlsWidget(
                            isPlaying: isPlaying,
                            onPlayPause: _togglePlayPause,
                            onPrevious: () {},
                            onNext: () {},
                          ),

                          SizedBox(height: 3.h),

                          // Secondary Controls
                          SecondaryControlsWidget(
                            isShuffleOn: isShuffleOn,
                            isRepeatOn: isRepeatOn,
                            onShuffleToggle: _toggleShuffle,
                            onRepeatToggle: _toggleRepeat,
                          ),

                          SizedBox(height: 2.h),

                          // Volume Control
                          VolumeControlWidget(
                            volume: volume,
                            onVolumeChange: _onVolumeChange,
                          ),
                        ],
                      ),
                    ),
                  ),

                  // Bottom Actions
                  Padding(
                    padding:
                        EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
                    child: BottomActionsWidget(
                      onQueueTap: () {
                        Navigator.pushNamed(context, '/playlists');
                      },
                      onCastTap: () {},
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

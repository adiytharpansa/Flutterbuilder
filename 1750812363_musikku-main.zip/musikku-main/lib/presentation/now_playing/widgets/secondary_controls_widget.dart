import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SecondaryControlsWidget extends StatelessWidget {
  final bool isShuffleOn;
  final bool isRepeatOn;
  final VoidCallback onShuffleToggle;
  final VoidCallback onRepeatToggle;

  const SecondaryControlsWidget({
    super.key,
    required this.isShuffleOn,
    required this.isRepeatOn,
    required this.onShuffleToggle,
    required this.onRepeatToggle,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        // Shuffle Button
        GestureDetector(
          onTap: onShuffleToggle,
          child: Container(
            padding: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: isShuffleOn
                  ? AppTheme.secondaryLight.withValues(alpha: 0.2)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(8),
            ),
            child: CustomIconWidget(
              iconName: 'shuffle',
              color: isShuffleOn
                  ? AppTheme.secondaryLight
                  : Colors.white.withValues(alpha: 0.6),
              size: 24,
            ),
          ),
        ),

        SizedBox(width: 8.w),

        // Repeat Button
        GestureDetector(
          onTap: onRepeatToggle,
          child: Container(
            padding: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: isRepeatOn
                  ? AppTheme.secondaryLight.withValues(alpha: 0.2)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(8),
            ),
            child: CustomIconWidget(
              iconName: 'repeat',
              color: isRepeatOn
                  ? AppTheme.secondaryLight
                  : Colors.white.withValues(alpha: 0.6),
              size: 24,
            ),
          ),
        ),
      ],
    );
  }
}

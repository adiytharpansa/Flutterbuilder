import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class VolumeControlWidget extends StatelessWidget {
  final double volume;
  final ValueChanged<double> onVolumeChange;

  const VolumeControlWidget({
    super.key,
    required this.volume,
    required this.onVolumeChange,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        CustomIconWidget(
          iconName: 'volume_down',
          color: Colors.white.withValues(alpha: 0.6),
          size: 20,
        ),
        Expanded(
          child: SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: Colors.white.withValues(alpha: 0.8),
              inactiveTrackColor: Colors.white.withValues(alpha: 0.3),
              thumbColor: Colors.white,
              overlayColor: Colors.white.withValues(alpha: 0.2),
              trackHeight: 0.3.h,
              thumbShape: RoundSliderThumbShape(enabledThumbRadius: 1.w),
            ),
            child: Slider(
              value: volume,
              onChanged: onVolumeChange,
              min: 0.0,
              max: 1.0,
            ),
          ),
        ),
        CustomIconWidget(
          iconName: 'volume_up',
          color: Colors.white.withValues(alpha: 0.6),
          size: 20,
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class BottomActionsWidget extends StatelessWidget {
  final VoidCallback onQueueTap;
  final VoidCallback onCastTap;

  const BottomActionsWidget({
    super.key,
    required this.onQueueTap,
    required this.onCastTap,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        // Queue Button
        GestureDetector(
          onTap: onQueueTap,
          child: Container(
            padding: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                CustomIconWidget(
                  iconName: 'queue_music',
                  color: Colors.white.withValues(alpha: 0.8),
                  size: 20,
                ),
                SizedBox(width: 2.w),
                Text(
                  'Antrian',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Colors.white.withValues(alpha: 0.8),
                      ),
                ),
              ],
            ),
          ),
        ),

        // Cast/AirPlay Button
        GestureDetector(
          onTap: onCastTap,
          child: Container(
            padding: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                CustomIconWidget(
                  iconName: 'cast',
                  color: Colors.white.withValues(alpha: 0.8),
                  size: 20,
                ),
                SizedBox(width: 2.w),
                Text(
                  'Cast',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Colors.white.withValues(alpha: 0.8),
                      ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

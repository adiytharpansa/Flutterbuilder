import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_image_widget.dart';

class AlbumArtworkWidget extends StatelessWidget {
  final String imageUrl;
  final AnimationController rotationController;
  final bool isPlaying;

  const AlbumArtworkWidget({
    super.key,
    required this.imageUrl,
    required this.rotationController,
    required this.isPlaying,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 70.w,
        height: 70.w,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.5),
              blurRadius: 20,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: RotationTransition(
            turns: rotationController,
            child: CustomImageWidget(
              imageUrl: imageUrl,
              width: 70.w,
              height: 70.w,
              fit: BoxFit.cover,
            ),
          ),
        ),
      ),
    );
  }
}

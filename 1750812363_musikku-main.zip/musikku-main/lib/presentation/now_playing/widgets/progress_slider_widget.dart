import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class ProgressSliderWidget extends StatelessWidget {
  final double currentPosition;
  final String currentTime;
  final String duration;
  final ValueChanged<double> onSeek;

  const ProgressSliderWidget({
    super.key,
    required this.currentPosition,
    required this.currentTime,
    required this.duration,
    required this.onSeek,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            activeTrackColor: AppTheme.secondaryLight,
            inactiveTrackColor: Colors.white.withValues(alpha: 0.3),
            thumbColor: AppTheme.secondaryLight,
            overlayColor: AppTheme.secondaryLight.withValues(alpha: 0.2),
            trackHeight: 0.5.h,
            thumbShape: RoundSliderThumbShape(enabledThumbRadius: 1.5.w),
          ),
          child: Slider(
            value: currentPosition,
            onChanged: onSeek,
            min: 0.0,
            max: 1.0,
          ),
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 2.w),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                currentTime,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.white.withValues(alpha: 0.8),
                    ),
              ),
              Text(
                duration,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.white.withValues(alpha: 0.8),
                    ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

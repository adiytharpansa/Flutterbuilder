import 'package:on_audio_query/on_audio_query.dart';
import '../models/song.dart';

class StorageService {
  final OnAudioQuery _audioQuery = OnAudioQuery();

  Future<List<Song>> scanLocalMusic() async {
    // Request permission
    bool permissionStatus = await _audioQuery.permissionsStatus();
    if (!permissionStatus) {
      await _audioQuery.permissionsRequest();
    }

    // Query for songs
    List<SongModel> songModels = await _audioQuery.querySongs(
      sortType: SongSortType.TITLE,
      orderType: OrderType.ASC_OR_SMALLER,
      uriType: UriType.EXTERNAL,
      ignoreCase: true,
    );

    // Map to Song objects
    return songModels.map((songModel) => Song.fromSongModel(songModel)).toList();
  }
}

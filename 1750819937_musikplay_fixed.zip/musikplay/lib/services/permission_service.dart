import 'package:permission_handler/permission_handler.dart';

class PermissionService {
  Future<bool> requestPermissions() async {
    Map<Permission, PermissionStatus> statuses = await [
      Permission.storage,
      Permission.audio,
    ].request();

    if (statuses[Permission.storage]!.isGranted || statuses[Permission.audio]!.isGranted) {
      return true;
    } else {
      return false;
    }
  }
}

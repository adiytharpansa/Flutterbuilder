import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../providers/music_provider.dart';
import '../widgets/song_tile.dart';
import '../widgets/bottom_player.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Musikplay'),
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {
              context.go('/search');
            },
          )
        ],
      ),
      body: Consumer<MusicProvider>(
        builder: (context, provider, child) {
          switch (provider.songStatus) {
            case SongStatus.loading:
              return Center(child: CircularProgressIndicator());
            case SongStatus.error:
              return Center(child: Text('Error: ${provider.errorMessage}'));
            case SongStatus.empty:
              return Center(child: Text('No music found on your device.'));
            case SongStatus.success:
              return ListView.builder(
                itemCount: provider.songs.length,
                itemBuilder: (context, index) {
                  return SongTile(song: provider.songs[index]);
                },
              );
          }
        },
      ),
      bottomNavigationBar: BottomPlayer(),
    );
  }
}

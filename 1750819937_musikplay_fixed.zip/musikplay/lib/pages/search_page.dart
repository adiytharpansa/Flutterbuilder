import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/music_provider.dart';
import '../widgets/song_tile.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({Key? key}) : super(key: key);

  @override
  _SearchPageState createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  String _searchQuery = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          onChanged: (value) {
            setState(() {
              _searchQuery = value;
            });
          },
          decoration: InputDecoration(
            hintText: 'Search for a song...',
            border: InputBorder.none,
          ),
        ),
      ),
      body: Consumer<MusicProvider>(
        builder: (context, provider, child) {
          final filteredSongs = provider.songs.where((song) {
            final titleLower = song.title.toLowerCase();
            final artistLower = song.artist.toLowerCase();
            final searchLower = _searchQuery.toLowerCase();
            return titleLower.contains(searchLower) || artistLower.contains(searchLower);
          }).toList();

          return ListView.builder(
            itemCount: filteredSongs.length,
            itemBuilder: (context, index) {
              return SongTile(song: filteredSongs[index]);
            },
          );
        },
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/music_provider.dart';
import '../widgets/player_controls.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:audio_video_progress_bar/audio_video_progress_bar.dart';
import 'package:audio_service/audio_service.dart';
import '../services/audio_service.dart';

class PlayerPage extends StatelessWidget {
  const PlayerPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final musicProvider = Provider.of<MusicProvider>(context);
    final audioHandler = musicProvider.audioHandler;

    return Scaffold(
      appBar: AppBar(
        title: Text('Now Playing'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      extendBodyBehindAppBar: true,
      body: StreamBuilder<MediaItem?>(
        stream: audioHandler.mediaItem,
        builder: (context, snapshot) {
          final mediaItem = snapshot.data;
          if (mediaItem == null) {
            return Center(child: Text('No song selected'));
          }

          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Hero(
                  tag: 'albumArt',
                  child: CachedNetworkImage(
                    imageUrl: mediaItem.artUri.toString(),
                    fit: BoxFit.cover,
                    width: 300,
                    height: 300,
                    errorWidget: (context, url, error) => Icon(Icons.music_note, size: 300),
                  ),
                ),
                SizedBox(height: 32),
                Text(mediaItem.title, style: Theme.of(context).textTheme.headlineSmall, textAlign: TextAlign.center),
                SizedBox(height: 8),
                Text(mediaItem.artist ?? 'Unknown Artist', style: Theme.of(context).textTheme.titleMedium, textAlign: TextAlign.center),
                SizedBox(height: 32),
                StreamBuilder<PlaybackState>(
                  stream: audioHandler.playbackState,
                  builder: (context, snapshot) {
                    final playbackState = snapshot.data;
                    final progress = playbackState?.updatePosition ?? Duration.zero;
                    final total = mediaItem.duration ?? Duration.zero;

                    return ProgressBar(
                      progress: progress,
                      total: total,
                      onSeek: audioHandler.seek,
                    );
                  },
                ),
                PlayerControls(),
                SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    StreamBuilder<AudioServiceShuffleMode>(
                        stream: audioHandler.playbackState.map((state) => state.shuffleMode ?? AudioServiceShuffleMode.none).distinct(),
                        builder: (context, snapshot) {
                            final shuffleMode = snapshot.data ?? AudioServiceShuffleMode.none;
                            return IconButton(
                                icon: Icon(Icons.shuffle, color: shuffleMode != AudioServiceShuffleMode.none ? Theme.of(context).colorScheme.primary : Colors.grey),
                                onPressed: () {
                                     audioHandler.setShuffleMode(shuffleMode == AudioServiceShuffleMode.none ? AudioServiceShuffleMode.all : AudioServiceShuffleMode.none);
                                },
                            );
                        }
                    ),
                    StreamBuilder<AudioServiceRepeatMode>(
                       stream: audioHandler.playbackState.map((state) => state.repeatMode).distinct(),
                       builder: (context, snapshot) {
                            final repeatMode = snapshot.data ?? AudioServiceRepeatMode.none;
                            const icons = {
                                AudioServiceRepeatMode.none: Icons.repeat,
                                AudioServiceRepeatMode.one: Icons.repeat_one,
                                AudioServiceRepeatMode.all: Icons.repeat,
                                AudioServiceRepeatMode.group: Icons.repeat,
                            };
                            const cycleModes = {
                                AudioServiceRepeatMode.none: AudioServiceRepeatMode.one,
                                AudioServiceRepeatMode.one: AudioServiceRepeatMode.all,
                                AudioServiceRepeatMode.all: AudioServiceRepeatMode.none,
                            };
                            return IconButton(
                                icon: Icon(icons[repeatMode], color: repeatMode != AudioServiceRepeatMode.none ? Theme.of(context).colorScheme.primary : Colors.grey),
                                onPressed: () {
                                    audioHandler.setRepeatMode(cycleModes[repeatMode] ?? AudioServiceRepeatMode.none);
                                },
                            );
                       }
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

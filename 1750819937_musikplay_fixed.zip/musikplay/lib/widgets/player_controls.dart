import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/music_provider.dart';

class PlayerControls extends StatelessWidget {
  const PlayerControls({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<MusicProvider>(
      builder: (context, provider, child) {
        return Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            IconButton(onPressed: provider.previous, icon: Icon(Icons.skip_previous)),
            IconButton(
              onPressed: () {
                if (provider.isPlaying) {
                  provider.pause();
                } else {
                  provider.resume();
                }
              },
              icon: Icon(provider.isPlaying ? Icons.pause : Icons.play_arrow),
              iconSize: 48,
            ),
            IconButton(onPressed: provider.next, icon: Icon(Icons.skip_next)),
          ],
        );
      },
    );
  }
}

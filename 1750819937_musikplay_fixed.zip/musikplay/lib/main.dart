import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'package:audio_service/audio_service.dart';
import 'providers/music_provider.dart';
import 'pages/home_page.dart';
import 'pages/player_page.dart';
import 'pages/search_page.dart';
import 'themes/app_theme.dart';
import 'services/audio_service.dart';

Future<void> main() async {
  final audioHandler = await AudioService.init(
    builder: () => AudioPlayerHandler(),
    config: AudioServiceConfig(
      androidNotificationChannelId: 'com.ryanheise.myapp.channel.audio',
      androidNotificationChannelName: 'Audio playback',
      androidNotificationOngoing: true,
    ),
  );
  runApp(MyApp(audioHandler: audioHandler));
}

class MyApp extends StatelessWidget {
  final AudioPlayerHandler audioHandler;

  const MyApp({Key? key, required this.audioHandler}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => MusicProvider(audioHandler),
      child: MaterialApp.router(
        title: 'Musikplay',
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.system,
        routerConfig: _router,
      ),
    );
  }
}

final _router = GoRouter(
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => const HomePage(),
      routes: [
        GoRoute(
          path: 'player',
          builder: (context, state) => const PlayerPage(),
        ),
        GoRoute(
          path: 'search',
          builder: (context, state) => const SearchPage(),
        ),
      ],
    ),
  ],
);

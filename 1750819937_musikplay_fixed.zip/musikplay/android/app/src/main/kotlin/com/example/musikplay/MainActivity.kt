
package com.example.musikplay

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

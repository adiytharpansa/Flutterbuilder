# 🎵 Musikplay Flutter

![Flutter](https://img.shields.io/badge/Flutter-3.22.0%2B-blue.svg)
![Platform](https://img.shields.io/badge/Platform-Android-green.svg)
![License](https://img.shields.io/badge/License-MIT-yellow.svg)

Aplikasi pemutar musik offline modern untuk Android yang dibangun dengan Flutter. Desain minimalis dengan performa tinggi dan antarmuka yang elegan.

## ✨ Fitur Utama

### 🎧 Audio Player
- ✅ Putar file audio lokal (mp3, wav, aac, flac)
- ✅ Background audio playback dengan notification
- ✅ Player controls lengkap (play, pause, next, previous)
- ✅ Mode shuffle dan loop (single, all)
- ✅ Audio metadata dan album art display

### 🎨 UI/UX Modern
- ✅ Tema minimalis dan elegan
- ✅ Dark mode otomatis (mengikuti sistem)
- ✅ Floating bottom player (miniplayer)
- ✅ Smooth animations dan transitions
- ✅ Responsive layout (support tablet)
- ✅ Custom fonts dengan Google Fonts

### 🔍 Functionality
- ✅ Auto scan penyimpanan lokal
- ✅ Search functionality
- ✅ Permission handling yang proper
- ✅ No login required - langsung gunakan

## 📱 Requirements

- **Flutter:** 3.22.0 atau lebih baru
- **Android SDK:** Minimal API 21 (Android 5.0)
- **Target:** Android 14 compatible
- **Android Embedding:** V2+

## 🚀 Quick Start

### 1. Clone Repository
```bash
git clone https://github.com/YOUR_USERNAME/musikplay-flutter.git
cd musikplay-flutter
```

### 2. Install Dependencies
```bash
flutter pub get
```

### 3. Run Application
```bash
# Debug mode
flutter run

# Release APK
flutter build apk --release
```

### 4. Install pada Device
```bash
flutter install
```

## Project Structure

```
lib/
├── main.dart
├── models/
│   ├── song.dart
│   └── player_state.dart
├── services/
│   ├── audio_service.dart
│   ├── storage_service.dart
│   └── permission_service.dart
├── providers/
│   └── music_provider.dart
├── pages/
│   ├── home_page.dart
│   ├── player_page.dart
│   └── search_page.dart
├── widgets/
│   ├── song_tile.dart
│   ├── bottom_player.dart
│   ├── player_controls.dart
│   └── custom_widgets.dart
├── utils/
│   ├── constants.dart
│   └── helpers.dart
└── themes/
    └── app_theme.dart
```

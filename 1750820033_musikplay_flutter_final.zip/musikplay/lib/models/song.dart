import 'package:on_audio_query/on_audio_query.dart';

class Song {
  final int id;
  final String title;
  final String artist;
  final String? album;
  final String? albumArt;
  final String uri;
  final int duration;

  Song({
    required this.id,
    required this.title,
    required this.artist,
    this.album,
    this.albumArt,
    required this.uri,
    required this.duration,
  });

  factory Song.fromSongModel(SongModel songModel) {
    return Song(
      id: songModel.id,
      title: songModel.title,
      artist: songModel.artist ?? 'Unknown Artist',
      album: songModel.album,
      albumArt: songModel.uri,
      uri: songModel.uri,
      duration: songModel.duration ?? 0,
    );
  }
}

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../providers/music_provider.dart';
import 'player_controls.dart';

class BottomPlayer extends StatelessWidget {
  const BottomPlayer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<MusicProvider>(
      builder: (context, provider, child) {
        if (provider.currentSong == null) {
          return SizedBox.shrink();
        }
        return GestureDetector(
          onTap: () => context.go('/player'),
          child: Container(
            color: Theme.of(context).colorScheme.surfaceVariant,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  title: Text(provider.currentSong!.title, maxLines: 1),
                  subtitle: Text(provider.currentSong!.artist, maxLines: 1),
                  trailing: IconButton(icon: Icon(Icons.keyboard_arrow_up), onPressed: () {
                    context.go('/player');
                  }),
                ),
                PlayerControls(),
              ],
            ),
          ),
        );
      },
    );
  }
}

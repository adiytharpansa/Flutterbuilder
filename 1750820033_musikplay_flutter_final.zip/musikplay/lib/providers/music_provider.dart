import 'package:flutter/material.dart';
import '../models/song.dart';
import '../services/storage_service.dart';
import '../services/audio_service.dart';
import 'package:audio_service/audio_service.dart';

enum SongStatus { loading, success, error, empty }

class MusicProvider extends ChangeNotifier {
  final StorageService _storageService = StorageService();
  final AudioPlayerHandler audioHandler;

  List<Song> _songs = [];
  List<Song> get songs => _songs;

  Song? _currentSong;
  Song? get currentSong => _currentSong;

  bool _isPlaying = false;
  bool get isPlaying => _isPlaying;

  SongStatus _songStatus = SongStatus.loading;
  SongStatus get songStatus => _songStatus;

  String _errorMessage = '';
  String get errorMessage => _errorMessage;

  MusicProvider(this.audioHandler) {
    _loadSongs();
    audioHandler.playbackState.listen((playbackState) {
      _isPlaying = playbackState.playing;
      final mediaItem = audioHandler.mediaItem.value;
      if (mediaItem != null) {
        try {
          _currentSong = _songs.firstWhere((song) => song.uri == mediaItem.id);
        } catch (e) {
          // Handle case where song is not in the list
          _currentSong = null;
        }
      }
      notifyListeners();
    });
  }

  Future<void> _loadSongs() async {
    try {
      _songStatus = SongStatus.loading;
      notifyListeners();
      final scannedSongs = await _storageService.scanLocalMusic();
      if (scannedSongs.isEmpty) {
        _songStatus = SongStatus.empty;
      } else {
        _songs = scannedSongs;
        audioHandler.addSongs(_songs);
        _songStatus = SongStatus.success;
      }
    } catch (e) {
      _errorMessage = "Failed to load songs: $e";
      _songStatus = SongStatus.error;
    }
    notifyListeners();
  }

  void play(Song song) {
    final index = _songs.indexOf(song);
    if(index != -1) {
        audioHandler.skipToQueueItem(index);
    }
  }

  void pause() {
    audioHandler.pause();
  }

  void resume() {
    audioHandler.play();
  }

  void next() {
    audioHandler.skipToNext();
  }

  void previous() {
    audioHandler.skipToPrevious();
  }
}

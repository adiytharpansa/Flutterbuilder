import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:provider/provider.dart';
import 'package:musikplay/providers/music_provider.dart';
import 'package:musikplay/pages/home_page.dart';
import 'package:musikplay/services/audio_service.dart';

class MockMusicProvider extends Mock implements MusicProvider {}
class MockAudioPlayerHandler extends Mock implements AudioPlayerHandler {}

void main() {
  late MockMusicProvider mockMusicProvider;

  setUp(() {
    mockMusicProvider = MockMusicProvider();
    when(mockMusicProvider.audioHandler).thenReturn(MockAudioPlayerHandler());
  });

  Widget createWidgetUnderTest() {
    return ChangeNotifierProvider<MusicProvider>.value(
      value: mockMusicProvider,
      child: MaterialApp(
        home: HomePage(),
      ),
    );
  }

  testWidgets('shows loading indicator when status is loading', (widgetTester) async {
    // arrange
    when(mockMusicProvider.songStatus).thenReturn(SongStatus.loading);
    when(mockMusicProvider.songs).thenReturn([]);

    // act
    await widgetTester.pumpWidget(createWidgetUnderTest());

    // assert
    expect(find.byType(CircularProgressIndicator), findsOneWidget);
  });

  testWidgets('shows error message when status is error', (widgetTester) async {
    // arrange
    when(mockMusicProvider.songStatus).thenReturn(SongStatus.error);
    when(mockMusicProvider.errorMessage).thenReturn('Test Error');
    when(mockMusicProvider.songs).thenReturn([]);

    // act
    await widgetTester.pumpWidget(createWidgetUnderTest());

    // assert
    expect(find.text('Error: Test Error'), findsOneWidget);
  });

  testWidgets('shows empty message when status is empty', (widgetTester) async {
    // arrange
    when(mockMusicProvider.songStatus).thenReturn(SongStatus.empty);
    when(mockMusicProvider.songs).thenReturn([]);

    // act
    await widgetTester.pumpWidget(createWidgetUnderTest());

    // assert
    expect(find.text('No music found on your device.'), findsOneWidget);
  });

  // Add more tests for the success case
}

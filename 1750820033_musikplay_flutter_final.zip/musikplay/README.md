# Musikplay Flutter

A modern, offline music player for Android built with Flutter.

## Features

- Plays local audio files (mp3, wav, aac, flac)
- Background audio playback
- Minimalist UI with automatic dark mode
- Search functionality
- Player controls (play, pause, next, previous)
- Shuffle and loop modes
- Displays audio metadata and album art

## How to Build

1.  **Clone the repository:**
    ```sh
    git clone https://github.com/your-username/musikplay-flutter.git
    cd musikplay-flutter
    ```

2.  **Get dependencies:**
    ```sh
    flutter pub get
    ```

3.  **Run the app:**
    ```sh
    flutter run
    ```

## Project Structure

```
lib/
├── main.dart
├── models/
│   ├── song.dart
│   └── player_state.dart
├── services/
│   ├── audio_service.dart
│   ├── storage_service.dart
│   └── permission_service.dart
├── providers/
│   └── music_provider.dart
├── pages/
│   ├── home_page.dart
│   ├── player_page.dart
│   └── search_page.dart
├── widgets/
│   ├── song_tile.dart
│   ├── bottom_player.dart
│   ├── player_controls.dart
│   └── custom_widgets.dart
├── utils/
│   ├── constants.dart
│   └── helpers.dart
└── themes/
    └── app_theme.dart
```

import 'package:flutter/material.dart';
import '../models/song.dart';
import '../utils/helpers.dart';
import 'package:provider/provider.dart';
import '../providers/music_provider.dart';

class SongTile extends StatelessWidget {
  final Song song;

  const SongTile({Key? key, required this.song}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(song.title, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text(song.artist, maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: Text(formatDuration(Duration(milliseconds: song.duration))),
      onTap: () {
        context.read<MusicProvider>().play(song);
      },
    );
  }
}

class PlayerState {
  final bool isPlaying;
  final bool isShuffling;
  final bool isLooping;

  PlayerState({
    this.isPlaying = false,
    this.isShuffling = false,
    this.isLooping = false,
  });

  PlayerState copyWith({
    bool? isPlaying,
    bool? isShuffling,
    bool? isLooping,
  }) {
    return PlayerState(
      isPlaying: isPlaying ?? this.isPlaying,
      isShuffling: isShuffling ?? this.isShuffling,
      isLooping: isLooping ?? this.isLooping,
    );
  }
}

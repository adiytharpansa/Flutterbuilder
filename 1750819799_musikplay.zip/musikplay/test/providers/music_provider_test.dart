import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:musikplay/providers/music_provider.dart';
import 'package:musikplay/services/audio_service.dart';
import 'package:musikplay/services/storage_service.dart';
import 'package:musikplay/models/song.dart';

class MockAudioPlayerHandler extends Mock implements AudioPlayerHandler {}
class MockStorageService extends Mock implements StorageService {}

void main() {
  late MusicProvider musicProvider;
  late MockAudioPlayerHandler mockAudioHandler;
  late MockStorageService mockStorageService;

  setUp(() {
    mockAudioHandler = MockAudioPlayerHandler();
    mockStorageService = MockStorageService();
    musicProvider = MusicProvider(mockAudioHandler);
    // Manually inject the mock storage service
    // musicProvider.storageService = mockStorageService;
  });

  test('Initial values are correct', () {
    expect(musicProvider.songs, []);
    expect(musicProvider.songStatus, SongStatus.loading);
  });

  group('loadSongs', () {
    final tSongs = [Song(id: 1, title: 'Test Song', artist: 'Test Artist', uri: 'test/uri', duration: 1000)];

    test('should get songs from the storage service', () async {
      // arrange
      when(mockStorageService.scanLocalMusic()).thenAnswer((_) async => tSongs);
      // act
      await musicProvider.loadSongsForTest(mockStorageService);
      // assert
      expect(musicProvider.songs, tSongs);
      verify(mockStorageService.scanLocalMusic());
    });

    test('should change status to success when songs are loaded', () async {
      // arrange
      when(mockStorageService.scanLocalMusic()).thenAnswer((_) async => tSongs);
      // act
      await musicProvider.loadSongsForTest(mockStorageService);
      // assert
      expect(musicProvider.songStatus, SongStatus.success);
    });

     test('should change status to empty when no songs are found', () async {
      // arrange
      when(mockStorageService.scanLocalMusic()).thenAnswer((_) async => []);
      // act
      await musicProvider.loadSongsForTest(mockStorageService);
      // assert
      expect(musicProvider.songStatus, SongStatus.empty);
    });

    test('should change status to error when an exception occurs', () async {
      // arrange
      when(mockStorageService.scanLocalMusic()).thenThrow(Exception('Test Error'));
      // act
      await musicProvider.loadSongsForTest(mockStorageService);
      // assert
      expect(musicProvider.songStatus, SongStatus.error);
      expect(musicProvider.errorMessage, contains('Test Error'));
    });
  });
}

extension TestMusicProvider on MusicProvider {
  Future<void> loadSongsForTest(StorageService storageService) async {
    try {
      songStatus = SongStatus.loading;
      notifyListeners();
      final scannedSongs = await storageService.scanLocalMusic();
      if (scannedSongs.isEmpty) {
        songStatus = SongStatus.empty;
      } else {
        songs = scannedSongs;
        audioHandler.addSongs(songs);
        songStatus = SongStatus.success;
      }
    } catch (e) {
      errorMessage = "Failed to load songs: $e";
      songStatus = SongStatus.error;
    }
    notifyListeners();
  }
}
